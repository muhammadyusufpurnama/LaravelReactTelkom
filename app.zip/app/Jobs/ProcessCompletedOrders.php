<?php

namespace App\Jobs;

use Illuminate\Bus\Batchable;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Imports\CompletedOrdersImport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class ProcessCompletedOrders implements ShouldQueue
{
    use Batchable, Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $path;

    public function __construct(string $path)
    {
        $this->path = $path;
    }

    public function handle(): void
    {
        // PERBAIKAN: Gunakan Storage::path() untuk mendapatkan alamat file absolut
        $filePath = Storage::path($this->path);

        Log::info("Memulai job untuk memproses order complete dari file: {$this->path}");
        try {
            Excel::import(new CompletedOrdersImport, $filePath);
            Log::info("Selesai memproses file order complete.");
        } catch (\Exception $e) {
            Log::error("GAGAL memproses file order complete: " . $e->getMessage());
            $this->fail($e);
        } finally {
            // Hapus file setelah selesai
            Storage::delete($this->path);
        }
    }
}
