<?php

use App\Http\Controllers\AccountOfficerController;
use App\Http\Controllers\AnalysisDigitalProductController;
use App\Http\Controllers\DashboardDigitalProductController;
use App\Http\Controllers\DataReportController;
use App\Http\Controllers\GalaksiController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Di sini Anda dapat mendaftarkan rute web untuk aplikasi Anda. Rute-rute ini
| dimuat oleh RouteServiceProvider dan semuanya akan ditetapkan ke
| grup middleware "web". Buat sesuatu yang hebat!
|
*/

// Rute default, mengarahkan ke halaman login
Route::get('/', fn () => Redirect::route('login'));

// --- RUTE YANG MEMERLUKAN AUTENTIKASI ---
Route::middleware(['auth', 'verified'])->group(function () {
    /*
    |--------------------------------------------------------------------------
    | Rute Umum & Tampilan User
    |--------------------------------------------------------------------------
    */
    Route::get('/dashboard', [DashboardDigitalProductController::class, 'index'])->name('dashboard');
    Route::get('/dashboardDigitalProduct', [DashboardDigitalProductController::class, 'index'])->name('dashboardDigitalProduct');

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('/data-report', [DataReportController::class, 'index'])->name('data-report.index');
    Route::get('/data-report/export', [DataReportController::class, 'export'])->name('data-report.export');
    Route::get('/data-report/export/inprogress', [DataReportController::class, 'exportInProgress'])->name('data-report.exportInProgress');

    Route::get('/galaksi', [GalaksiController::class, 'index'])->name('galaksi.index');

    // Rute Progress Bar (digunakan bersama)
    Route::get('/import-progress/{batchId}', [AnalysisDigitalProductController::class, 'getImportProgress'])->name('import.progress');

    /*
    |--------------------------------------------------------------------------
    | Rute Khusus Admin & Superadmin (Area CMS)
    |--------------------------------------------------------------------------
    */
    Route::middleware(['role:admin,superadmin'])->prefix('admin')->name('admin.')->group(function () {
        // Grup Controller untuk Analisis Digital Product
        Route::controller(AnalysisDigitalProductController::class)->prefix('analysis-digital-product')->name('analysisDigitalProduct.')->group(function () {
            Route::get('/', 'index')->name('index');
            Route::post('/upload', 'upload')->name('upload');
            Route::post('/targets', 'updateTargets')->name('targets');
            Route::post('/upload-complete', 'uploadComplete')->name('uploadComplete');
            Route::post('/upload-cancel', 'uploadCancel')->name('uploadCancel');
            Route::post('/config', 'saveConfig')->name('saveConfig');
            Route::post('/reset-config', 'resetTableConfig')->name('resetConfig');
            Route::post('/clear-history', 'clearHistory')->name('clearHistory');
            Route::post('/export-report', 'exportReport')->name('export.report');
            Route::post('/custom-targets', 'saveCustomTargets')->name('saveCustomTargets');
            Route::get('/export/kpi-po', 'exportKpiPo')->name('export.kpiPo');
            Route::get('/export/inprogress', 'exportInProgress')->name('export.inprogress');
            Route::get('/export/history', 'exportHistory')->name('export.history');
        });

        // Rute untuk Analisis SOS
        Route::get('/analysis-sos', fn () => inertia('Admin/AnalysisSOS'))->name('analysisSOS.index');

        // Rute aksi update manual (menggunakan Route Model Binding)
        Route::put('/manual-update/complete/{documentData:order_id}', [AnalysisDigitalProductController::class, 'updateManualComplete'])->name('manual.update.complete');
        Route::put('/manual-update/cancel/{documentData:order_id}', [AnalysisDigitalProductController::class, 'updateManualCancel'])->name('manual.update.cancel');
        Route::put('/complete-update/progress/{documentData:order_id}', [AnalysisDigitalProductController::class, 'updateCompleteToProgress'])->name('complete.update.progress');
        Route::put('/complete-update/qc/{documentData:order_id}', [AnalysisDigitalProductController::class, 'updateCompleteToQc'])->name('complete.update.qc');
        Route::put('/complete-update/cancel/{documentData:order_id}', [AnalysisDigitalProductController::class, 'updateCompleteToCancel'])->name('complete.update.cancel');
        Route::put('/qc-update/{documentData:order_id}/progress', [AnalysisDigitalProductController::class, 'updateQcStatusToProgress'])->name('qc.update.progress');
        Route::put('/qc-update/{documentData:order_id}/done', [AnalysisDigitalProductController::class, 'updateQcStatusToDone'])->name('qc.update.done');
        Route::put('/qc-update/{documentData:order_id}/cancel', [AnalysisDigitalProductController::class, 'updateQcStatusToCancel'])->name('qc.update.cancel');

        // Rute Resource untuk Account Officer (hanya store dan update)
        Route::resource('account-officers', AccountOfficerController::class)->only(['store', 'update']);
    });

    /*
    |--------------------------------------------------------------------------
    | Rute HANYA untuk Superadmin
    |--------------------------------------------------------------------------
    */
    Route::middleware(['role:superadmin'])->group(function () {
        Route::resource('users', UserController::class);
    });
});

require __DIR__.'/auth.php';
